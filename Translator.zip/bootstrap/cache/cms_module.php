<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cms\\Providers\\CmsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cms\\Providers\\CmsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);