<?php

return [
    'name' => 'Front'
];
