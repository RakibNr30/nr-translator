<?php

namespace Modules\Front\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Front\Services\TypingService;

class TypingController extends Controller
{
    private $typingService;

    public function __construct(TypingService $typingService)
    {
        $this->typingService = $typingService;
    }

    public function index()
    {
        return view('front::typing.index');
    }

    public function typing(Request $request)
    {
        $data = $request->all()['n'];
        //$from = $data['source_lang'];
        $from = 'auto';
        $to = $data['source_lang'];
        $text = $data['text_to_translate'];
        return $this->typingService->Typing($from, $to, $text);
    }
}
