<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Module Front</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

       
       

    </head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>

        
        
    </body>
</html>
<?php /**PATH E:\CODINGs\MyProjects\Laravel-Framework\Translator\Modules/Front\Resources/views/layouts/master.blade.php ENDPATH**/ ?>