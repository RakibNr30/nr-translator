<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('/translate')); ?>" method="POST">
    <input type="text" name="data">
    <input type="submit">
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CODINGs\MyProjects\Laravel-Framework\Translator\Modules/Front\Resources/views/index.blade.php ENDPATH**/ ?>