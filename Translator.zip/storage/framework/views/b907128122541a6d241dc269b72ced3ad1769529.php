<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Free Online Translator - Translate.com</title>
    <link rel="stylesheet" href="/front/css/style.css">
    <script src="/front/js/jquery.min.js"></script>
</head>

<body id="index">
<script>
    const user_id = false;
</script>
<main>
    <div class="container">
        <div class="machineTranslationOuter">
            <div class="machineTranslation">
                <div class="machineTranslationBlock">
                    <div class="translator" data-element="translator" data-order-url="">

                        <div class="translator__side translator__from">
                            <div class="translator__reverse" data-element="reverse" onclick="getLanguageFromText('abcd')">
                                <div class="loader__inner"></div>
                            </div>
                            <div class="translator__language" data-language="source">
                                <div class="translator__language__variants" data-element="source_language_list" style="display: none">
                                    <span class="translator__language__variants__close" data-element="close_language_list" data-target="source_language"></span>
                                    <div class="translator__language__variants__header">
                                        Select source language </div>
                                    <div class="translator__language__variants__list" data-element="source_lang">
                                        <ul></ul>
                                    </div>
                                </div>
                                <div class="translator__language__selector">
										<span data-element="source_language">
										</span>
                                </div>
                            </div>
                            <textarea class="translator__field" data-gramm="false" placeholder="Type or paste text here to translate" autocomplete="off" data-element="source_text" name="text_from_lang"></textarea>
                            <ul class="translator__features">
                                <li class="icon icon__photo" data-element="show_app_notice" data-target="photo">
                                    photo
                                </li>
                                <li class="icon icon__voice" data-element="show_app_notice" data-target="voice">
                                    voice
                                </li>
                                <li class="icon icon__draw" data-element="show_app_notice" data-target="draw">
                                    input
                                </li>
                            </ul>
                            <div class="translator__detected" style="display: none;" data-element="detected_lang">
                                ?
                            </div>
                        </div>

                        <div class="translator__side translator__to">
                            <div class="translator__language" data-language="target">
                                <div class="translator__language__variants" data-element="target_language_list" style="display: none">
                                    <span class="translator__language__variants__close" data-element="close_language_list" data-target="target_language"></span>
                                    <div class="translator__language__variants__header">
                                        Select target language </div>
                                    <div class="translator__language__variants__list" data-element="translated_lang">
                                        <ul></ul>
                                    </div>
                                </div>
                                <div class="translator__language__selector">
										<span data-element="target_language">
										</span>
                                </div>
                            </div>
                            <textarea class="translator__field" id="translated_text" readonly></textarea>
                            <ul class="translator__features">
                                <li class="icon icon__copy" data-action="copy" data-after-copy-text="Copied" data-clipboard-target="#translated_text">
                                </li>
                                <li class="icon icon__share" data-action="share_link">
                                </li>
                            </ul>
                            <div class="translator__features  translator__features--play">
                                <div class="icon icon__audio icon__play" data-element="play_audio">
                                    play
                                </div>
                                <div class="icon icon__audio icon__stop hidden" data-element="stop_audio">
                                    stop
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    var language_mapping = [];

    var languages = [];
    languages['auto_detect'] = 'Auto Detect';
    language_mapping.push({
        code: 'auto_detect',
        name: 'Auto Detect'
    });

    language_mapping.push({
        code: 'af',
        name: 'Afrikaans'
    });
    languages['af'] = 'Afrikaans';
    language_mapping.push({
        code: 'ar',
        name: 'Arabic'
    });
    languages['ar'] = 'Arabic';
    language_mapping.push({
        code: 'bs',
        name: 'Bosnian (Latin)'
    });
    languages['bs'] = 'Bosnian (Latin)';
    language_mapping.push({
        code: 'bg',
        name: 'Bulgarian'
    });
    languages['bg'] = 'Bulgarian';
    language_mapping.push({
        code: 'ca',
        name: 'Catalan'
    });
    languages['ca'] = 'Catalan';
    language_mapping.push({
        code: 'zh',
        name: 'Chinese (Simplified)'
    });
    languages['zh'] = 'Chinese (Simplified)';
    language_mapping.push({
        code: 'zh-TW',
        name: 'Chinese (Traditional)'
    });
    languages['zh-TW'] = 'Chinese (Traditional)';
    language_mapping.push({
        code: 'hr',
        name: 'Croatian'
    });
    languages['hr'] = 'Croatian';
    language_mapping.push({
        code: 'cs',
        name: 'Czech'
    });
    languages['cs'] = 'Czech';
    language_mapping.push({
        code: 'da',
        name: 'Danish'
    });
    languages['da'] = 'Danish';
    language_mapping.push({
        code: 'nl',
        name: 'Dutch'
    });
    languages['nl'] = 'Dutch';
    language_mapping.push({
        code: 'en',
        name: 'English'
    });
    languages['en'] = 'English';
    language_mapping.push({
        code: 'et',
        name: 'Estonian'
    });
    languages['et'] = 'Estonian';
    language_mapping.push({
        code: 'tl',
        name: 'Filipino'
    });
    languages['tl'] = 'Filipino';
    language_mapping.push({
        code: 'fi',
        name: 'Finnish'
    });
    languages['fi'] = 'Finnish';
    language_mapping.push({
        code: 'fr',
        name: 'French'
    });
    languages['fr'] = 'French';
    language_mapping.push({
        code: 'de',
        name: 'German'
    });
    languages['de'] = 'German';
    language_mapping.push({
        code: 'el',
        name: 'Greek'
    });
    languages['el'] = 'Greek';
    language_mapping.push({
        code: 'ht',
        name: 'Haitian Creole'
    });
    languages['ht'] = 'Haitian Creole';
    language_mapping.push({
        code: 'iw',
        name: 'Hebrew'
    });
    languages['iw'] = 'Hebrew';
    language_mapping.push({
        code: 'hi',
        name: 'Hindi'
    });
    languages['hi'] = 'Hindi';
    language_mapping.push({
        code: 'mww',
        name: 'Hmong Daw'
    });
    languages['mww'] = 'Hmong Daw';
    language_mapping.push({
        code: 'hu',
        name: 'Hungarian'
    });
    languages['hu'] = 'Hungarian';
    language_mapping.push({
        code: 'is',
        name: 'Icelandic'
    });
    languages['is'] = 'Icelandic';
    language_mapping.push({
        code: 'id',
        name: 'Indonesian'
    });
    languages['id'] = 'Indonesian';
    language_mapping.push({
        code: 'it',
        name: 'Italian'
    });
    languages['it'] = 'Italian';
    language_mapping.push({
        code: 'ja',
        name: 'Japanese'
    });
    languages['ja'] = 'Japanese';
    language_mapping.push({
        code: 'tlh',
        name: 'Klingon'
    });
    languages['tlh'] = 'Klingon';
    language_mapping.push({
        code: 'ko',
        name: 'Korean'
    });
    languages['ko'] = 'Korean';
    language_mapping.push({
        code: 'lv',
        name: 'Latvian'
    });
    languages['lv'] = 'Latvian';
    language_mapping.push({
        code: 'lt',
        name: 'Lithuanian'
    });
    languages['lt'] = 'Lithuanian';
    language_mapping.push({
        code: 'ms',
        name: 'Malay'
    });
    languages['ms'] = 'Malay';
    language_mapping.push({
        code: 'mt',
        name: 'Maltese'
    });
    languages['mt'] = 'Maltese';
    language_mapping.push({
        code: 'no',
        name: 'Norwegian'
    });
    languages['no'] = 'Norwegian';
    language_mapping.push({
        code: 'fa',
        name: 'Persian'
    });
    languages['fa'] = 'Persian';
    language_mapping.push({
        code: 'pl',
        name: 'Polish'
    });
    languages['pl'] = 'Polish';
    language_mapping.push({
        code: 'pt',
        name: 'Portuguese'
    });
    languages['pt'] = 'Portuguese';
    language_mapping.push({
        code: 'ro',
        name: 'Romanian'
    });
    languages['ro'] = 'Romanian';
    language_mapping.push({
        code: 'ru',
        name: 'Russian'
    });
    languages['ru'] = 'Russian';
    language_mapping.push({
        code: 'sr',
        name: 'Serbian (Cyrillic)'
    });
    languages['sr'] = 'Serbian (Cyrillic)';
    language_mapping.push({
        code: 'sr-La',
        name: 'Serbian (Latin)'
    });
    languages['sr-La'] = 'Serbian (Latin)';
    language_mapping.push({
        code: 'sk',
        name: 'Slovak'
    });
    languages['sk'] = 'Slovak';
    language_mapping.push({
        code: 'sl',
        name: 'Slovenian'
    });
    languages['sl'] = 'Slovenian';
    language_mapping.push({
        code: 'es',
        name: 'Spanish'
    });
    languages['es'] = 'Spanish';
    language_mapping.push({
        code: 'sv',
        name: 'Swedish'
    });
    languages['sv'] = 'Swedish';
    language_mapping.push({
        code: 'ta',
        name: 'Tamil'
    });
    languages['ta'] = 'Tamil';
    language_mapping.push({
        code: 'th',
        name: 'Thai'
    });
    languages['th'] = 'Thai';
    language_mapping.push({
        code: 'tr',
        name: 'Turkish'
    });
    languages['tr'] = 'Turkish';
    language_mapping.push({
        code: 'uk',
        name: 'Ukrainian'
    });
    languages['uk'] = 'Ukrainian';
    language_mapping.push({
        code: 'ur',
        name: 'Urdu'
    });
    languages['ur'] = 'Urdu';
    language_mapping.push({
        code: 'vi',
        name: 'Vietnamese'
    });
    languages['vi'] = 'Vietnamese';
    language_mapping.push({
        code: 'cy',
        name: 'Welsh'
    });
    languages['cy'] = 'Welsh';
    language_mapping.push({
        code: 'yua',
        name: 'Yucatec Maya'
    });
    languages['yua'] = 'Yucatec Maya';
</script>

<script src="/front/js/clipboard.min.js"></script>
<script src="/front/js/jquery.autogrow-textarea.min.js"></script>
<script src="/front/js/script.js"></script>

</body>

</html><?php /**PATH E:\CODINGs\MyProjects\Laravel-Framework\Translator\Modules/Front\Resources/views/translator/translate.blade.php ENDPATH**/ ?>